public class RogueAI extends AI {

    private int firewallProtection;
    private int alertLevel;
    private final int maxAlert;

    public RogueAI(int firewallProtection, int alertLevel, int maxAlert, Coordinates cannonTarget, Coordinates secretHQ){
        super(cannonTarget, secretHQ);
        this.firewallProtection = firewallProtection;
        this.alertLevel = alertLevel;
        this.maxAlert = maxAlert;
    }

    public RogueAI(int firewallProtection,int maxAlert, Coordinates cannonTarget, Coordinates secretHQ){
        super(cannonTarget,secretHQ);

        this.firewallProtection = firewallProtection;
        this.maxAlert = maxAlert;

        alertLevel = 0;
    }

    public RogueAI(int firewallProtection, Coordinates cannonTarget, Coordinates secretHQ){
        super(cannonTarget, secretHQ);

        this.firewallProtection = firewallProtection;

        alertLevel = 0;
        maxAlert = 10;
    }

    // Constructor delegation?

    public int getFirewallProtection(){
        return firewallProtection;
    }

    public int getAlertLevel(){
        return alertLevel;
    }

    public int getMaxAlert(){
        return maxAlert;
    }

    public void lowerFirewall(){
        firewallProtection -= 2;
        alertLevel++;
    }

    @Override
    public boolean shouldSwapCannonTarget(){
        return (firewallProtection <= 0);
    }

    @Override
    public boolean shouldSelfDestruct(){
        return (alertLevel >= maxAlert);
    }

    public String toString(){
        return String.format("Dr. Chipotle's guacamole cannon is currently pointed at latitude: %4.2f, longitude: %4.2f, and is at alert level %d with firewall protection %d", cannonTarget.getLatitude(), cannonTarget.getLongitude(), alertLevel, firewallProtection);
    }
}
