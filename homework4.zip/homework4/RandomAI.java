import java.util.Random;

public class RandomAI extends AI {
    private static final Random randomizer = new Random();

    public RandomAI(Coordinates cannonTarget, Coordinates secretHQ){
        super(cannonTarget, secretHQ);
    }

    @Override
    public boolean shouldSwapCannonTarget(){
        if(randomizer.nextInt(100) < 50){
            return true;
        } else return false;
    }

    @Override
    public boolean shouldSelfDestruct(){
        if(randomizer.nextInt(100) < 50){
            return true;
        } else return false;
    }
}
