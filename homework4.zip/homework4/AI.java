public abstract class AI {

    Coordinates cannonTarget;
    Coordinates secretHQ;
    boolean destructed = false;

    public AI(Coordinates cannonTarget, Coordinates secretHQ){
        this.cannonTarget = cannonTarget;
        this.secretHQ = secretHQ;
    }

    public boolean getDestructed(){
        return destructed;
    }

    public Coordinates getCannonTarget(){
        return cannonTarget;
    }

    public Coordinates getSecretHQ(){
        return secretHQ;
    }

    public boolean swapCannonTarget(Coordinates newCoords){
        if(!destructed && newCoords != cannonTarget){
            if(shouldSwapCannonTarget()){
                cannonTarget = newCoords;
                return true;
            } else if(shouldSelfDestruct()){
                selfDestruct();
                return false;
            } else return false;
        }  else return false;
    }

    public abstract boolean shouldSwapCannonTarget();

    public void selfDestruct(){
        destructed = true;
    }

    public abstract boolean shouldSelfDestruct();

    public String toString(){
        return String.format("Dr. Chipotle's guacamole cannon is currently pointed at (latitude: %f, longitude: %f).", cannonTarget.getLatitude(), cannonTarget.getLongitude());
    }
}
