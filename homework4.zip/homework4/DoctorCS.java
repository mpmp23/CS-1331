public class DoctorCS {
    
    AI ai;
    String secretIdentity;
    int jlaid;
    boolean safe; // whether we are safe

    public DoctorCS(AI ai, String secretIdentity, int jlaid){
        this.ai = ai;
        this.secretIdentity = secretIdentity;
        this.jlaid = jlaid;
        this.safe = false;
    }

    public void saveTheDay(){
        if(ai instanceof RogueAI){
            RogueAI rogue = (RogueAI)ai;
            while(rogue.getFirewallProtection() > 0){
                rogue.lowerFirewall();
            }
        }
        safe = ai.swapCannonTarget(ai.getSecretHQ());
    }

    public String getStatus(){
        if(safe){
            return "Doctor CS has saved the day!";
        } else if(!safe && ai.getDestructed()){
            return "Dr. Chipotle has succeeded in his plan...";
        } else return "Georgia Tech is still in danger!";
    }

    public String toString(){
        return String.format("%s aka Doctor CS with JLAID: %d",
            secretIdentity, jlaid);
    }

    public AI getAI(){
        return ai;
    }

    public int getJlaid(){
        return jlaid;
    }
}
