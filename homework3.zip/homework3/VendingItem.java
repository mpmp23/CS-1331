enum VendingItem {

    Lays(1.5),
    Doritos(1.5),
    Coke(2.5),
    Ramblin_Reck_Toy(180.75),
    Rubiks_Cube(30),
    Rat_Cap(15),
    FASET_Lanyard(10),
    Graphing_Calculator(120),
    UGA_Diploma(0.1),
    Pie(3.14),
    Clicker(55.55),
    Cheetos(1.25),
    Sprite(2.5),
    Red_Bull(4.75),
    Ramen(3.15),
    Cold_Pizza(0.99);

    private final double price;

    VendingItem(double price) {
        this.price = price;
    }

    public final double getPrice(){
        return price;
    }

    public String toString(){
        return String.format("%4.2f",price);
    }
}