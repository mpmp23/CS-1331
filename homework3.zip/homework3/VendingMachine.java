import java.util.Random;
//import java.util.Scanner;

public class VendingMachine {
    /** @author mpmp23
     * MAKE JAVADOC COMMENTS FOR EACH CLASS
     */
    private static double totalSales = 0; // update this every time a sale that MAKES MONEY is made.

    private VendingItem[][][] shelf = new VendingItem[6][3][5];

    private int luckyChance = 0;

    private Random rand = new Random();

    VendingItem[] all_Items = VendingItem.values();

    public VendingMachine(){ // so, this is an array of vendingitems that have a name and price

        for(int i = 0; i < 6; i++){ // filling up our vending machine!
            for(int j = 0; j < 3; j++){
                for(int k = 0; k < 5; k++){
                    shelf[i][j][k] = all_Items[(int)(rand.nextInt(all_Items.length))];
                }
            }
        }

        restock();
    }

    public VendingItem vend(String code){

        /*Scanner input = new Scanner(System.in);
        System.out.println("Please enter code of product you would like to purchase: ");
        String code = input.nextLine();*/

        int row;
        int column;

        code = code.toLowerCase();

        if(code.length() == 2 && code.matches("[a-f][0-3]")){

            row = code.charAt(0) - 'a';
            column = code.charAt(1) - '0';
        } else{
            System.out.println("Error");
            return null;
        }

        VendingItem selection = shelf[row][column][0]; // your choice!

        // Here we are gonna check whether that position from our code is avaialble
        if(selection == null){
            System.out.println("Sorry, that selection isn't available!");
            return null;
        } else{
            // move the 'stack' back to front of vending machine
            for(int position = 1; position < shelf[row][column].length; position++){
                shelf[row][column][position - 1] = shelf[row][column][position];
            }
            boolean promoResult = free();

            // now to update total sales!
            if(!promoResult){
                totalSales += selection.getPrice();
            } else{}

            return selection;
        }
        
    }

    private boolean free(){
        if(rand.nextInt(100)< luckyChance){
            System.out.println("Congrats, you won a free prize!"); // boolean
            luckyChance = 0;
            return true;
            // Give them the free prize.
        } else{
            luckyChance += 1;
            return false;
        }
    }

    public void restock(){
        for(int i = 0; i < 6; i++){
            for(int j = 0; j < 3; j++){
                for(int k = 0; k < 5; k++){
                    if(shelf[i][j][k] == null){
                        shelf[i][j][k] = all_Items[(int)(rand.nextInt(all_Items.length))];
                    } else{}
                }
            }
        }
    }

    public static double getTotalSales(){
        return totalSales;
    }

    public int getNumberOfItems(){ // returns the total number of items in the vending machine!
        int totalNumber = 0;
        for(int i = 0; i < 6; i++){
            for(int j = 0; j < 3; j++){
                for(int k = 0; k < 5; k++){
                    if(shelf[i][j][k] != null){
                        totalNumber += 1;
                    } else{}
                }
            }
        }
        return totalNumber;
    }

    public double getTotalValue(){
        double total = 0;
        for(int i = 0; i < 6; i++){
            for(int j = 0; j < 3; j++){
                for(int k = 0; k < 5; k++){
                    total += shelf[i][j][k].getPrice();
                }
            }
        }
        return total;
    }

    public int getLuckyChance(){
        return luckyChance;
    }

    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("----------------------------------------------------------"
            + "------------\n");
        s.append("                            VendaTron 9000                "
            + "            \n");
        for (int i = 0; i < shelf.length; i++) {
            s.append("------------------------------------------------------"
                + "----------------\n");
            for (int j = 0; j < shelf[0].length; j++) {
                VendingItem item = shelf[i][j][0];
                String str = String.format("| %-20s ",
                    (item == null ? "(empty)" : item.name()));
                s.append(str);
            }
            s.append("|\n");
        }
        s.append("----------------------------------------------------------"
            + "------------\n");
        s.append(String.format("There are %d items with a total "
            + "value of $%.2f.%n", getNumberOfItems(), getTotalValue()));
        s.append(String.format("Total sales across vending machines "
            + "is now: $%.2f.%n", getTotalSales()));
        return s.toString();
    }
    
}
