import java.util.*;
import java.io.*;

public class SourceModel {

    int[][] matrix = new int[26][26]; // Array initialized for our 26 characters!
    double[][] probMatrix = new double[26][26];
    String modelName;

    public SourceModel(String modelName, String fileName) throws Exception {

        this.modelName = modelName;

        System.out.println("Training " + modelName + " model ...");

        FileReader corpusReader = new FileReader(new File(fileName + ""));
        /** while(corpusReader.read() != -1){
            System.out.println(corpusReader.read());
        } */

        int currentRead;
        int previous = -1;

        while((currentRead = corpusReader.read()) != -1){
            char current = Character.toLowerCase((char)currentRead);
            if(!Character.isLetter(current)) { // this makes sure it's only letters. continue says to ignore this read.
                continue;
            }

            int currentColumn = current - 'a';

            // store in matrix
            if(previous != -1){
                matrix[previous][currentColumn]++;
            }

            // now, need to store current before we move onto next
            previous = currentColumn;
            
        }

        // Probability matrix! 

        double[] totalRow = new double[26];

        for(int row = 0; row <= 25; row++){
            int total = 0;
            for(int i = 0; i <= 25; i++){
                total = matrix[row][i] + total;
            }
            totalRow[row] = total; // this gives us a list of all of the sums of each row.
        }

        for(int r = 0; r <= 25; r++){
            for(int c = 0; c <= 25; c++){
                probMatrix[r][c] = (matrix[r][c] + 1.0) / (totalRow[r] + 26.0); // Dividing each count by the sum of all the counts in the row.
                }
            }
    
        int nanCount = 0;
        for (int r = 0; r < 26; r++) {
            for (int c = 0; c < 26; c++) {
            if (Double.isNaN(probMatrix[r][c])) nanCount++;
            }
        }
        System.out.println("NaNs in probMatrix: " + nanCount);

        System.out.println("Done.\n");
}        
    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);
        String fileName;
        String modelName;
        ArrayList<String> inputList = new ArrayList<>();
        ArrayList<SourceModel> models = new ArrayList<>();

        /** while(input.hasNext()){
            inputList.add(input.next());
        }*/ 
        while(input.hasNextLine()){
            String line = input.nextLine().trim();

            if (line.equals("DONE")) {
                break; // this is a 'sentinel'
            }
        
            if (!line.isEmpty()) {
                inputList.add(line);
            }
        }
        if (!input.hasNextLine()) {
            throw new IllegalArgumentException("Missing test line after DONE.");
        }
        String test = input.nextLine();
        

        int n = 0;
        while(n < inputList.size()){
            fileName = inputList.get(n);
            modelName = nameFromFile(fileName);

            SourceModel model = new SourceModel(modelName, fileName);
            models.add(model);

            n++;
        }

        //String test = inputList.get(inputList.size() - 1);

        System.out.println("Analyzing: " + test);

        ArrayList<Double> probabilities = new ArrayList<>();

        // Use each model to compute probability the test text was made by the model.
        for(int k = 0; k < models.size(); k++){
            SourceModel m = models.get(k);
            double prob = m.probability(test); // Probability for this specific model.

            probabilities.add(prob); // makes a list of probabilities

        }
        // add all of the probabilities together and then store new probabilities for each model.

        ArrayList<Double> normalizedProbabilities = new ArrayList<>();
        double total = 0;
        for(int m = 0; m < probabilities.size(); m++){
            total += probabilities.get(m);
        }
        if(total == 0){
            for (int i = 0; i < probabilities.size(); i++) {
                normalizedProbabilities.add(1.0 / probabilities.size());
            }
        } else{
        for(int f = 0; f < probabilities.size(); f++){
            normalizedProbabilities.add(probabilities.get(f) / total);
        }
    }
   
        System.out.println("RAW probs = " + probabilities);
        System.out.println("SUM = " + total);
        for(int p = 0; p < models.size(); p++){
            System.out.println("Probability that test string is " + (models.get(p)).modelName + ": " + normalizedProbabilities.get(p));
        }


    }


    public String getName() {
        return modelName;
        //String shortModelName = fileName.substring(0,fileName.length()-7);
    }

    public static String nameFromFile(String fileName) {
        int dot = fileName.lastIndexOf('.');
        return (dot > 0) ? fileName.substring(0, dot) : fileName;
    }

    public String toString() {
       StringBuilder sb = new StringBuilder();
       for(int i = 0; i <= 25; i++){
        for(int j = 0; j <= 25; j++){
            sb.append(matrix[i][j]).append("  ");
        }
        sb.append("\n");
       }
       return sb.toString();
    }


    public double probability(String test) {
        test = test.toLowerCase();
        StringBuilder cleaned = new StringBuilder();
        for (int i = 0; i < test.length(); i++) {
            char ch = test.charAt(i);
            if (ch >= 'a' && ch <= 'z') cleaned.append(ch);
        }
        test = cleaned.toString();

        if (test.length() < 2) return 0.0;

        double probability = 1.0;
        for (int i = 0; i < test.length() - 1; i++) {
            int a = test.charAt(i) - 'a';
            int b = test.charAt(i + 1) - 'a';

            probability *= probMatrix[a][b];

    }
    return probability;
}
}