/**
 * TransactionType enum for ATM Transactions.
 *
 * @author CS1331 TAs
 * @version 1.1
 */
public enum TransactionType {
    WITHDRAWAL, DEPOSIT
}