public class MyList<E> implements List<E>  {

    E[] elements;
    int size;

    public MyList(){
        elements = (E[]) new Object[INITIAL_CAPACITY];
        size = 0;
    }

    public MyList(int capacity) {
        size = 0;
        if (capacity < 0){
            throw new IllegalArgumentException();
        }
        elements = (E[]) new Object[capacity];
    }

    public void add(E e){
        if(e == null){
            throw new IllegalArgumentException();
        }
        if(size != elements.length){
            elements[size] = e;
            size++;
        }

        if(size == elements.length){
            int length = elements.length * 2;
            E[] newList = (E[]) new Object[length];
            newList[newList.length - 1] = e;
            for(int i = elements.length - 1; i >= 0; i--){
            for(int n = newList.length - 1; n >= 0; n--){
                newList[n - 1] = elements[i];
            }
        }
        elements = newList;
        }
    }


    public E get(int index){
        if(index > elements.length - 1 || index < 0){
            throw new IndexOutOfBoundsException();
        }
        return elements[index];
    }

    public void replace(E e, E replaceWith){
        if(e.equals(null) || replaceWith == null){
            throw new IllegalArgumentException();
        }
        for(int i = 0; i < size; i++){
            if(elements[i] == e){
                elements[i] = replaceWith;
            } else;
        }
    }

    public int remove(E e){
        int count = 0;

        for(int i = 0; i < size; i++){
            if(elements[i] == e){
                elements[i] = null;
                count++;
                size--;
            }
        }
        
        return count;
    }

    public int contains(E e){
        int count = 0;

        for(int i = 0; i < elements.length; i++){
            if(elements[i] == e){
                count++;
            }
        }
        
        return count;
    }

    public boolean isEmpty(){
        for(int i = 0; i < size; i++){
            if(elements[i] == null){
                size = 0;
                return true;
            }
        }
        return false;
    }
    
    public void clear(){
        for(int i = 0; i < size; i++){
            elements[i] = null;
            size = 0;
        }
    }
    
    public int size(){
        int count = 0;

        for(int i = 0; i < elements.length; i++){
            if(elements[i] != null){
                count++;
            }
        }

        return count;
    }

    public E[] toArray(E[] e){
        for(int i = 0; i < e.length; i++){
            for(int f = 0; f < elements.length; f++){
                if(elements[f] != null){
                    e[i] = elements[f];
                }
            }
        }
        return e;
    }

}