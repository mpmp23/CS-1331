import java.util.function.Predicate;

public class Account {
    
    List<Transaction> pastTransactions;

    public Account(List<Transaction> pastTransactions){
        this.pastTransactions = pastTransactions;
    }

    Transaction getTransaction(int n){
        return pastTransactions.get(n);
    }

    List<Transaction> findTransactionsByPredicate(Predicate<Transaction> predicate){
        List<Transaction> filteredTransactions = new MyList<>();

        for(int i = 0; i < pastTransactions.size(); i++){
            if(predicate.test(pastTransactions.get(i))){
                filteredTransactions.add(pastTransactions.get(i));
            }
        }

        return filteredTransactions;
    }

    public class AmountPredicate implements Predicate<Transaction> {
        
        double targetAmount;

        public AmountPredicate(double targetAmount){
            this.targetAmount = targetAmount;
        }

        public boolean test(Transaction t){
            return t.getAmount() == targetAmount;
        }

    }

    List<Transaction> getTransactionsByAmount(double amount){
        
        AmountPredicate amountPredicate = new AmountPredicate(amount);

        return findTransactionsByPredicate(amountPredicate);
    }

    List<Transaction> getWithdrawals(){

        Predicate<Transaction> p = new Predicate<Transaction>() {
            public boolean test(Transaction t){
                return t.getType() == TransactionType.WITHDRAWAL;
            }
        };

        return findTransactionsByPredicate(p);
    }

    List<Transaction> getDeposits(){

        Predicate<Transaction> p = (Transaction t) -> t.getType() == TransactionType.DEPOSIT;
        
        return findTransactionsByPredicate(p);
    }

    List<Transaction> getTransactionsWithCommentLongerThan(int length){
        
        Predicate<Transaction> p = (Transaction t) -> {
            if(t.hasComment()){
                return (t.comment.get().length() > length);
            } else return false;
        };

        return findTransactionsByPredicate(p);
    }

    List<Transaction> getTransactionsWithComment(){

        Predicate<Transaction> p = (Transaction t) -> t.hasComment();

        return findTransactionsByPredicate(p);
    }

    public List<Transaction> getPastTransactions(){
        return pastTransactions;
    }
}